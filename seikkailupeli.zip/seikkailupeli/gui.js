/* This class handles the graphical user interface and is yours to complete. */
/* config.js contains important configuration data in an object. It's used e.g. with config.mapWidth. */
import { config } from './config.js';
import { AdventureGame } from "./adventuregame.js";
import { AdventureMap } from './adventuremap.js';

export class Gui {
    constructor(game) {
        this.game = game;
        this.icons = this.preloadImages();
    }
    
    // TO DO
    // Draws the map. Parameter "map" contains a two-dimensional array of MapUnit objects. Each square is 40x40 pixels.
    // Width and height in squares are specified in config file.
    drawMap(map) {
        
        // draw background color (lightgreen)
        
        // go through the map (loop inside loop) and draw contents to map canvas
        // draw terrain (forest or town) first, then enemy if there is one
        // items are not shown (they're hidden)
        
    }

    // TO DO
    // draw player character (NOTE: x and y are actual coordinates, not grid squares)
    drawPlayer(x, y) {
        
    }
    
    // TO DO
    // draw the inventory items, given as list (max number of inventory items is 4 - return immediately if more)
    drawInventory(items) {
        // check number of items
        
        // draw the 4-square grid
        
        // draw item image for each item in list (image is 50x50 pixels)
        
    }

    // TO DO
    // Draw the text given as parameter to the narrative box. Use 14px Helvetica as font.
    // Use wrapText method to split it to lines, then draw each line with fillText method. Method returns arrays within an array.
    // Loop through the items in the outer array. In each item (inner array), slots are text, x coordinate and y coordinate in that order.
    drawNarrative(text) {
 
    }

    // Text wrapper for narrative. DO NOT TOUCH!
    // Modified from https://fjolt.com/article/html-canvas-how-to-wrap-text
    wrapText(text) {
        let canvas = document.getElementById(config.narrativeCanvas);
        let context = canvas.getContext('2d');
        // First, start by splitting all of our text into words, but splitting it into an array split by spaces
        let words = text.split(' ');
        let line = ''; // This will store the text of the current line
        let testLine = ''; // This will store the text when we add a word, to test if it's too long
        let lineArray = []; // This is an array of lines, which the function will return

        let x = 5;
        let y = 15;
    
        // Lets iterate over each word
        for(var n = 0; n < words.length; n++) {
            // Create a test line, and measure it..
            testLine += `${words[n]} `;
            let metrics = context.measureText(testLine);
            let testWidth = metrics.width;
            // If the width of this test line is more than the max width
            if (testWidth > (config.narrativeWidth - 10) && n > 0) {
                // Then the line is finished, push the current line into "lineArray"
                lineArray.push([line, x, y]);
                // Increase the line height, so a new line is started
                y += config.lineHeight;
                // Update line and test line to use this word as the first word on the next line
                line = `${words[n]} `;
                testLine = `${words[n]} `;
            }
            else {
                // If the test line is still less than the max width, then add the word to the current line
                line += `${words[n]} `;
            }
            // If we never reach the full max width, then there is only one line.. so push it into the lineArray so we return something
            if(n === words.length - 1) {
                lineArray.push([line, x, y]);
            }
        }
        // Return the line array
        return lineArray;
    }

    // TO DO
    // enable arrow key buttons
    enableArrowKeys() {

    }

    // TO DO
    // disable arrow key buttons (called by map unit when dialogue activates and only OK / Cancel are allowed)
    disableArrowKeys() {

    }

    // Returns an "array" (object) with names and corresponding image objects. DO NOT TOUCH!
    // Use images with arrayName.imageName, e.g. if your array is in variable gameImages, then gameImages.player for player character image.
    preloadImages() {
        // List all image to preload here - image filename should be name + .png
        const imageNames = ['player', 'town', 'enemy', 'tree', 'potion'];

        let loadCount = 0;
        let loadTotal = imageNames.length;
    
        var loadedImages = {};

        // Create all image objects and store them in the loadedImages object.
        for (let i = 0; i < imageNames.length; i++) {
            let image = new Image();

            // in order for onload handler to have access to the AdventureGame object, it has to be a property of the image (stupid principle)
            image.game = this.game;
            image.src = 'images/' + imageNames[i] + '.png';

            loadedImages[(imageNames[i])] = image;
    
            // Add onload event handler.
            image.onload = function () {
                loadCount++;
                if (loadCount == loadTotal) {
                    // Done loading, can initialize game
                    this.game.init();
                }
            };
        }
    
        // Return an array of images
        return loadedImages;
    }
}