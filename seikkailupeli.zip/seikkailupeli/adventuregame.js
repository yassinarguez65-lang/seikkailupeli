/* This is the main class of the game. Almost everything is created here and calls pass through this object. */
import { config } from './config.js';
import { AdventureMap } from './adventuremap.js';
import { PlayerCharacter } from "./playercharacter.js";
import { Gui } from './gui.js';

export class AdventureGame {
    constructor() {
        this.player = new PlayerCharacter();
        this.gui = new Gui(this);
        this.adventureMap = new AdventureMap(this);

        // images must be preloaded before drawn to canvas
        this.gui.preloadImages();

        this.initialized = false;

        // TO DO: add any new object variables here
    }

    // Called to start the game when images have been preloaded.
    init(){
        // Some kind of race condition(?) is making init be called twice after image preloading. This hack prevents it.
        if(this.initialized) {
            return;
        }
        this.initialized = true;

        // draw map, inventory and narration windows
        this.gui.drawMap(this.adventureMap.map);
        this.gui.drawPlayer(40 * this.player.x, 40 * this.player.y);
        this.gui.drawInventory(this.player.items);
        this.gui.drawNarrative("You have entered this land in search of the Miraculous Rock. Your quest is to find it and take it to the local town. Your only clue is that it's buried under a tree.");

        // create event listeners for buttons (that arrow function is needed or else "this" means the button)
        document.getElementById(config.upButton).addEventListener('click', () => this.movePlayerUp());
        document.getElementById(config.downButton).addEventListener('click', () => this.movePlayerDown());
        document.getElementById(config.leftButton).addEventListener('click', () => this.movePlayerLeft());
        document.getElementById(config.rightButton).addEventListener('click', () => this.movePlayerRight());
        document.getElementById(config.okButton).addEventListener('click', () => this.adventureMap.map[this.player.x][this.player.y].inputOk());
        document.getElementById(config.cancelButton).addEventListener('click', () => this.adventureMap.map[this.player.x][this.player.y].inputCancel());
        
        // create event listener for inventory canvas
        document.getElementById(config.inventoryCanvas).addEventListener("click", (e) =>
        {
            // TO DO: figure out which inventory slot was clicked (0-3) based on the coordinates

            // currently only potions are supported
            if(selectedItem == 'potion') {
                this.player.useItem();
                this.player.healDamage(6);
                this.gui.drawInventory(this.player.items);
                this.gui.drawNarrative(`You use a healing potion. Your current health is ${this.player.currentHp} / ${this.player.maxHp}.`);
            }
            // EXTENSION POINT: add more item handlers
        });
    }

    // TO DO
    // movement functions (update player coordinates, redraw map and initiate the events of the map square entered)
    movePlayerUp() {

    }
    movePlayerDown() {

    }

    movePlayerLeft() {

    }

    movePlayerRight() {

    }

    // TO DO -- if implementing smooth movement, modify the robot moving code for this function
    // note that the current step and whether moving or not should be object variables, so they're saved between function calls
    playerTakeStep(targetX, targetY) {
 
    }
}

// start the game by creating object
new AdventureGame();
 
